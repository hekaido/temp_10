"use strict";

const BROWSER = typeof browser !== "undefined" ? browser : chrome;
const DEFAULT_GALLERY_URL = "https://gallery.hekaido.space/gallery/index.html";

const input = document.getElementById("url");
const status = document.getElementById("status");

BROWSER.storage.local.get("galleryUrl").then((v) => {
  input.value = v.galleryUrl || DEFAULT_GALLERY_URL;
});

document.getElementById("save").addEventListener("click", async () => {
  const value = input.value.trim() || DEFAULT_GALLERY_URL;
  await BROWSER.storage.local.set({ galleryUrl: value });
  status.textContent = "Сохранено — обновите вкладку с «Галереей».";
  setTimeout(() => { status.textContent = ""; }, 2500);
});
