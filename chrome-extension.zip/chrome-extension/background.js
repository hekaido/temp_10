/* Диск отдаёт свою страницу «Галерея» с CSP вида `frame-src 'self' <их-домены>`, который не
 * пускает наш iframe с gallery.hekaido.space — это ограничение их страницы, не нашего скрипта
 * (content.js тут бессилен: CSP применяется браузером к загрузке ресурса, а не к тому, кто вставил
 * тег). Единственный легальный способ снять это именно для нашей страницы — удалить заголовок
 * Content-Security-Policy из ответа на `files.sberdisk.ru/gallery` через declarativeNetRequest.
 *
 * Регистрируем правило и статически (manifest.json -> declarative_net_request), и здесь, через
 * API: статический rule_resources — более новый механизм, который Safari поддерживает не во всех
 * версиях; updateDynamicRules — старее и надёжнее. Если один способ не сработает, должен сработать
 * второй.
 */
"use strict";

const BROWSER = typeof browser !== "undefined" ? browser : chrome;

const RULE = {
  id: 1,
  priority: 1,
  action: {
    type: "modifyHeaders",
    responseHeaders: [
      { header: "content-security-policy", operation: "remove" },
      { header: "content-security-policy-report-only", operation: "remove" },
    ],
  },
  condition: {
    urlFilter: "||files.sberdisk.ru/gallery*",
    resourceTypes: ["main_frame"],
  },
};

BROWSER.declarativeNetRequest
  .updateDynamicRules({ removeRuleIds: [1], addRules: [RULE] })
  .then(() => console.log("[gallery-embed] правило CSP зарегистрировано"))
  .catch((e) => console.error("[gallery-embed] не удалось зарегистрировать правило CSP:", e));
