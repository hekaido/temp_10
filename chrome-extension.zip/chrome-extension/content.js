/* Встраивает галерею tagger в раздел «Галерея» на files.sberdisk.ru.
 *
 * Диск — React-приложение, и его DOM трогать нельзя: более ранняя версия этого скрипта подменяла
 * детей узла GalleryView__content через replaceChildren, и когда React на следующей перерисовке
 * обнаруживал чужие детей вместо своих, всё приложение падало с собственным экраном ошибки
 * («Что-то пошло не так»). Поэтому теперь скрипт вообще не меняет чужой DOM — он просто рисует
 * отдельный слой (position: fixed) поверх раздела «Галерея», повторяя его размер и положение.
 * React про этот слой ничего не знает и не может из-за него сломаться.
 */
"use strict";

const BROWSER = typeof browser !== "undefined" ? browser : chrome;
const CONTENT_CLASS_PREFIX = "GalleryView__content"; // тело раздела «Галерея» в разметке Диска
const DEFAULT_GALLERY_URL = "https://gallery.hekaido.space/gallery/index.html";
const OVERLAY_ID = "tagger-gallery-overlay";

let target = null; // элемент Диска, который сейчас накрыт слоем
let overlayEl = null;

function buildOverlay(url) {
  const el = document.createElement("div");
  el.id = OVERLAY_ID;
  el.style.cssText =
    "position:fixed;z-index:2147483000;overflow:hidden;background:#ecf2f5;" +
    "border-radius:12px;box-shadow:0 4px 32px rgba(5,53,117,.25)";
  const iframe = document.createElement("iframe");
  iframe.src = url;
  iframe.title = "Галерея";
  iframe.style.cssText = "display:block;width:100%;height:100%;border:0;background:#ecf2f5";
  el.appendChild(iframe);
  document.documentElement.appendChild(el);
  return el;
}

function place() {
  if (!target || !target.isConnected) {
    teardown();
    return;
  }
  const r = target.getBoundingClientRect();
  if (r.width < 10 || r.height < 10) {
    overlayEl.style.display = "none"; // раздел временно не на экране — слой тоже прячем
    return;
  }
  overlayEl.style.display = "block";
  overlayEl.style.left = `${Math.round(r.left)}px`;
  overlayEl.style.top = `${Math.round(r.top)}px`;
  overlayEl.style.width = `${Math.round(r.width)}px`;
  overlayEl.style.height = `${Math.round(r.height)}px`;
}

function teardown() {
  if (overlayEl) {
    overlayEl.remove();
    overlayEl = null;
  }
  target = null;
}

async function galleryUrl() {
  try {
    const stored = await BROWSER.storage.local.get("galleryUrl");
    return stored.galleryUrl || DEFAULT_GALLERY_URL;
  } catch (e) {
    return DEFAULT_GALLERY_URL; // storage недоступен (например, strict-режим приватного окна)
  }
}

async function ensure() {
  const found = document.querySelector(`[class*="${CONTENT_CLASS_PREFIX}"]`);
  if (!found) {
    teardown(); // ушли со страницы «Галерея» — слой снимаем
    return;
  }
  if (found === target && overlayEl) {
    place(); // тот же узел — просто поправить позицию/размер
    return;
  }
  teardown();
  target = found;
  overlayEl = buildOverlay(await galleryUrl());
  place();
}

new MutationObserver(() => ensure()).observe(document.body, { childList: true, subtree: true });
window.addEventListener("resize", place);
window.addEventListener("scroll", place, true);
// Подстраховка на анимации интерфейса (сворачивание бокового меню и т.п.), которые не всегда
// укладываются в события resize/scroll/мутации DOM.
setInterval(place, 500);
ensure();
