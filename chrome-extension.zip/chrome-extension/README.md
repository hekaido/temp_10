# Расширение для Chrome: «Галерея в Диске»

То же самое, что `safari-extension/`, но под Chrome (Manifest V3). В отличие от Safari здесь не
нужны Xcode, подпись и Apple Developer Program — расширение из папки грузится напрямую, без сборки.

## Установка

1. Открой `chrome://extensions`.
2. Включи переключатель **«Режим разработчика»** (Developer mode) в правом верхнем углу.
3. Нажми **«Загрузить распакованное расширение»** (Load unpacked).
4. Укажи эту папку:
   ```
   /Users/hekaido/projects/SBER/label-matching/chrome-extension
   ```
5. Расширение сразу появится в списке и будет активно — ничего включать отдельно не нужно.

## Проверка

1. Открой `https://files.sberdisk.ru/gallery`.
2. В разделе «Галерея» должен появиться слой с нашей галереей (без https на `gallery.hekaido.space`
   он будет пустым — это отдельный процесс, см. остальной разговор про DNS).
3. Открой DevTools (⌘⌥I) → Console. Должна быть строка `[gallery-embed] правило CSP зарегистрировано`
   — значит фоновый скрипт запустился и снял `Content-Security-Policy` с ответа на `/gallery`,
   иначе их `frame-src` заблокирует наш iframe.
4. Если строки нет — открой `chrome://extensions`, найди «Галерея в Диске» → **Details** →
   **Inspect views: service worker** — откроется консоль самого фонового скрипта, там будет видно,
   если `declarativeNetRequest.updateDynamicRules` упал с ошибкой (например, из-за прав).

## Настройка адреса

Значок расширения на панели инструментов → поле адреса галереи (по умолчанию
`https://gallery.hekaido.space/gallery/index.html`) → «Сохранить».

## Если нужно обновить код

После правки `content.js`/`background.js`/`manifest.json` — на `chrome://extensions` нажми иконку
обновления (круглая стрелка) на карточке расширения, затем перезагрузи вкладку с Диском.
